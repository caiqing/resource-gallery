second asset
