# declared resource
