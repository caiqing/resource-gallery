# v2 core resource
